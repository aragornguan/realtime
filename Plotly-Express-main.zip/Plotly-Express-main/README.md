# Plotly-Express
This is the code for the Medium Blog Posts: https://medium.com/@malvik01
